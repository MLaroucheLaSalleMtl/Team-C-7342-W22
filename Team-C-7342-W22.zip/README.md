# Team-C-7342-W22
Team: Elizabeth D'Avignon, Coleman Ostach, Kevin Serra
