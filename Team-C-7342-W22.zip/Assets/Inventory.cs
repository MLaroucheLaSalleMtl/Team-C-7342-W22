using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public bool[] slotIsFilled;
    public GameObject[] inventSlots;

    public GameObject itemNeeded;
    

    //void Start()
    //{
        
    //}


    //void Update()
    //{
        
    //}
}
