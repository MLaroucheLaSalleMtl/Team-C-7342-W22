using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/*
 * Written by: Kevin Serra
 */

//public class VictoryCollision : MonoBehaviour
//{
//    [SerializedField] private Text SuccessText;


//    void Start()
//    {
//        SuccessText.enabled = false;
//    }

//    private void OnCollisionEnter2D(Collision2D collision)
//    {
//        if (collision.collider.CompareTag("Player"))
//        {
//            SuccessText.enabled = true;
//        }
//    }
//    void Update()
//    {
        
//    }
//}
